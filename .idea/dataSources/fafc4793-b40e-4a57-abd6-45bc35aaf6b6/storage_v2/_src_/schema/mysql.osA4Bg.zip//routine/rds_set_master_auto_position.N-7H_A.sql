create
    definer = rdsadmin@localhost procedure rds_set_master_auto_position(IN auto_position_mode tinyint(1))
BEGIN
  SELECT 'mysql.rds_set_master_auto_position is deprecated and will be removed in a future release. Use mysql.rds_set_source_auto_position instead. Refer to the documentation for more information on deprecated statements' AS Message;
  CALL mysql.rds_set_source_auto_position(auto_position_mode);
END;

