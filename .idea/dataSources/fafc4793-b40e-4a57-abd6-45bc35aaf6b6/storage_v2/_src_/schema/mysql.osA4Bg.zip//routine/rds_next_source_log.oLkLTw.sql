create
    definer = rdsadmin@localhost procedure rds_next_source_log(IN curr_source_log int)
BEGIN
  CALL mysql.rds_next_source_log_for_channel(curr_source_log, '');
END;

