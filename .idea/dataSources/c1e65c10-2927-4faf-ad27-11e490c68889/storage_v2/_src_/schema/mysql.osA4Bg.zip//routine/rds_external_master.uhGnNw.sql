create
    definer = rdsadmin@localhost procedure rds_external_master(IN phase varchar(10))
BEGIN
  SELECT 'mysql.rds_external_master is deprecated and will be removed in a future release. Use mysql.rds_external_source instead. Refer to the documentation for more information on deprecated statements' AS Message;
  CALL `mysql`.`rds_external_source`(phase);
END;

