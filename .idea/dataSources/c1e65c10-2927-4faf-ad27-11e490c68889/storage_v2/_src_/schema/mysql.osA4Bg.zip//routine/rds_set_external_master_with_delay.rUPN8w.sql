create
    definer = rdsadmin@localhost procedure rds_set_external_master_with_delay(IN host varchar(255), IN port int,
                                                                              IN user text, IN passwd text,
                                                                              IN name text, IN pos bigint unsigned,
                                                                              IN enable_ssl_encryption tinyint(1),
                                                                              IN delay int)
BEGIN
  SELECT 'mysql.rds_set_external_master_with_delay is deprecated and will be removed in a future release. Use mysql.rds_set_external_source_with_delay instead. Refer to the documentation for more information on deprecated statements' AS Message;
  CALL mysql.rds_set_external_source_with_delay(host, port, user, passwd, name, pos, enable_ssl_encryption, delay);
END;

grant select on user to 'mysql.session'@localhost;

